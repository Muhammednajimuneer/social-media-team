# /repurpose: one piece into every format

**Needs:** the source (transcript, article, video description, old post, PDF). Optional: which formats.

## Steps
1. Pull out the core idea, the 3 to 5 strongest points, and any real quotes or numbers in the source.
2. Default outputs (skip any the user doesn't want):
   - LinkedIn post (via /post rules)
   - Instagram caption plus an 8-slide carousel outline (via /caption and /carousel)
   - Facebook post
   - 30-second reel script (via /reel-script)
   - 3 short quote cards (one line each, taken from the source)
   - One X/Threads post
3. Adapt, don't copy. Each format gets its own hook and length.
4. Apply `banned-words.md` and finish with the approval gate.
