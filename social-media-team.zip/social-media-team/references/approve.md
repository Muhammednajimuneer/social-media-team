# /approve: final gate before posting

**Needs:** the final draft and the platform.

## Checklist (show each with a tick or a fix)
1. Every number, quote and claim is real and the user can back it up.
2. No [placeholder] left in the text.
3. Names, tags and @mentions are spelled right.
4. Links work and point where intended.
5. Length fits the platform; the hook shows before "see more".
6. One CTA. If it is a comment keyword, it matches the DM automation exactly.
7. No em dashes or AI words left (`banned-words.md`).
8. Hashtags: 3 to 5 on Instagram, 0 to 3 on LinkedIn.

## Then
Show the final text in a clean copy-ready block and ask:

> **Post this?** Reply *edit* with changes, or *yes* and copy it from the box above.

Claude never posts. The user copies, pastes and publishes.
