# /reel-script: timed short-video script

**Needs:** topic or offer, length (default 45 to 60 seconds), language. Optional: comment keyword for a DM automation, whether the speaker is on camera.

## The structure that works for viral tool/explainer reels
1. **Shock hook (0 to 3s):** one bold, specific line. Visual pattern-break on screen.
2. **Simple promise (3 to 6s):** what the viewer gets, in plain words.
3. **Stakes or price (6 to 8s):** why it matters now (free, fast, new).
4. **Scale (8 to 10s):** how much is inside ("21 skills, each with one job").
5. **Value beats (10 to about 30s):** one feature or point per 3 to 4 seconds, each with its own visual.
6. **"Best part" reveal (at about 60% of the runtime):** the strongest, most surprising point.
7. **Trust line:** remove the main objection ("you approve everything", "no coding needed").
8. **Easy + CTA (last 4 to 6s):** "Comment [KEYWORD] and I'll send you [thing]."

## Rules
- About 2.5 spoken words per second. Count them and fit the length.
- Subtitles in chunks of 2 to 4 words; mark the key word in each chunk for highlighting.
- The CTA keyword must be one short word, in capitals, identical in the script, the on-screen text and the caption.
- Only claim what is true and shown. No "guaranteed" results.

## Output
1. A table: Time | Spoken line | On-screen text | Visual / B-roll.
2. A caption (via /caption rules) with the keyword CTA.
3. Two alternative hooks.
4. Filming notes in 3 lines (framing, pace, where to cut).
5. The approval gate.
