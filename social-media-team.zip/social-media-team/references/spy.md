# /spy: break down a viral video and rebuild it

**Needs:** the video (link if it can be opened, otherwise a transcript, subtitles, screenshots or a description). Optional: the user's niche and offer.

## Part 1: Breakdown
1. **What it is about:** 3 to 4 sentences, including the caption and CTA.
2. **Full script:** a table of Time | Original line | English (translate if needed). Mark any words you filled in from context in [brackets].
3. **On-screen elements:** commands, demos, text, mock-ups shown.
4. **Structure:** the beats in order with timestamps (hook, promise, proof, reveal, trust, CTA).
5. **Visual style:** framing, colours, subtitle style, pace.
6. **Why it worked:** 3 to 5 reasons (curiosity, specificity, free offer, scale, social proof, a keyword CTA that drives comments).

## Part 2: Rebuild for the user
1. Keep the structure, change the angle. Find one way to make it better: more value, a real demo, a stronger reveal, a local or language twist.
2. Write a new script via /reel-script rules.
3. Never reuse the original creator's exact lines, visuals or branding. Borrow the formula, not the content.
