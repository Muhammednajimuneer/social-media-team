# /audit: what worked in recent posts

**Needs:** the last 5 to 20 posts with their numbers (views or reach, likes, comments, saves, shares, follows gained, date, format). Screenshots of insights are fine. Never invent missing numbers; work with what is given and say what is missing.

## Steps
1. Calculate per post: engagement rate (likes + comments + saves + shares divided by reach or views) and save+share rate.
2. Rank the posts. Show a table: Post | Format | Hook type | Topic | Reach | Engagement rate | Save+share rate.
3. Find patterns across the top 3 and bottom 3: hook formula, format, topic or pillar, length, posting day and time, CTA type.
4. Give the verdict:
   - **Keep:** 3 things to do more of.
   - **Stop:** 3 things to drop.
   - **Test:** 3 experiments for next week.
5. Be honest about small samples: with fewer than 10 posts, call patterns "early signals".
