# /carousel: slide-by-slide copy

**Needs:** topic or source content, platform. Optional: number of slides (default 8), brand colours.

## Structure
- **Slide 1, hook:** 8 words or fewer. Must make people swipe.
- **Slide 2, problem or promise:** why this matters.
- **Slides 3 to N-1, value:** one idea per slide, 30 words or fewer, numbered if it's a list.
- **Last slide, CTA:** save, share, follow, or comment a keyword.

## Output per slide
Headline | Body | Visual note (icon, screenshot, photo idea).

Then: a caption (via /caption rules), the approval gate, and the format note: Instagram 1080 x 1350 px, up to 20 slides; LinkedIn uploads as a PDF document.
