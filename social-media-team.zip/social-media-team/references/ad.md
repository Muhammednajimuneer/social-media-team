# /ad: Meta ad copy variants

**Needs:** the offer, audience, goal (leads, messages, sales, awareness), landing place (form, WhatsApp, website, DM). Optional: price, deadline, proof.

## Output
Five variants, each from a different angle: pain, outcome, proof, curiosity, offer.

For each:
- **Primary text:** first 125 characters carry the message (what shows before "more"). Total 50 to 150 words.
- **Headline:** 40 characters or fewer.
- **Description:** 30 characters or fewer.
- **CTA button:** for example Learn More, Sign Up, Send Message, Send WhatsApp Message.
- **Creative idea:** one line for the image or video.

## Meta ad policy reminders
- Don't assert or imply personal attributes ("Are you struggling with your weight?", "Other Muslims like you..."). Speak about the offer, not the person's traits.
- No unrealistic income or results claims, no fake countdowns, no misleading "free" if there is a catch.
- Proof must be real. Use [placeholder] where the user must add a real testimonial.

Apply `banned-words.md`, then the approval gate.
