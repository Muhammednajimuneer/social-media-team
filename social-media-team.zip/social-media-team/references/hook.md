# /hook: 10 hook options

**Needs:** topic. Optional: platform, text or video.

## Steps
1. Write 10 hooks using 10 different formulas from `hooks.md`. Label each with its formula name.
2. For video, add on-screen text (6 words or fewer) under each spoken hook.
3. Mark your top 3 with one line each on why they should win (specificity, tension, audience fit).
4. Offer to turn the user's pick into a full /post or /reel-script.

Keep every hook honest: only promise what the content will actually deliver.
