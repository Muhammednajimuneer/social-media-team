# /profile: optimise profiles

**Needs:** current profile text or screenshots, who the user wants to attract, what they offer. Ask for whatever is missing in one message.

## LinkedIn
- **Headline (220 characters max):** 3 options. Formula: who you help + the result + proof or credential. Keywords people actually search for.
- **About (2,600 characters max):** hook line, who you help and the problem, how you help, real proof (numbers, clients, credentials the user gave you), a personal line, CTA (DM, website, booking link).
- **Experience:** rewrite each role as 3 to 5 bullets that start with a verb and include a result where the user has one.
- **Featured:** suggest 3 items to pin (best post, lead magnet, offer page).

## Instagram
- **Name field:** name plus one searchable keyword (for example "Naji | AI Trainer").
- **Bio (150 characters max):** 3 options. Who you help, the result, proof, CTA pointing to the link.
- **Link in bio:** suggest one clear destination.
- **Highlights:** 4 to 6 highlight names.

## Facebook Page
- Intro (short, keyword-rich) and a CTA button suggestion.

Show before/after side by side. Apply `banned-words.md`. Never invent credentials or results.
