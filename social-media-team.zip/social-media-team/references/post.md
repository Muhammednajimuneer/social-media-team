# /post: write a full post

**Needs:** topic or idea, platform (LinkedIn, Instagram, Facebook, or all three). Optional: goal, audience, a real story or number.

## Steps
1. If topic or platform is missing, ask one short question. Otherwise go.
2. Pick the 3 best-fitting formulas from `hooks.md`. Write the post with the strongest one. List the other two hooks underneath as one-line alternatives.
3. Build the body in this order: hook, tension (the problem or the moment), value (specific steps, examples or insight), takeaway (one line), CTA (one action).
4. Format for the platform:
   - **LinkedIn:** first two lines under about 210 characters and strong enough to earn "see more". Short paragraphs of 1 to 2 lines. 150 to 300 words. 0 to 3 hashtags at the end. If there is a link, suggest putting it in the first comment.
   - **Instagram:** this is a caption, so hand over to the /caption rules.
   - **Facebook:** conversational, 40 to 150 words, end with a specific question or CTA.
   - **All three:** write a version for each. Do not paste the same text three times.
5. Apply `banned-words.md`.
6. Show the final post in a copy-ready block, then the approval gate.
