# /check: score a draft before posting

**Needs:** the draft and the platform.

## Steps
1. If code execution is available, save the draft to a text file and run:
   `python scripts/check.py draft.txt`
   It scores 5 measures: burstiness (sentence-length variety), specificity (numbers and names), slop density (AI words), fingerprint (AI patterns and em dashes) and voice (first person and contractions).
2. If code execution is not available, assess the same 5 measures by reading the draft.
3. Also check:
   - Hook: would it stop the scroll? Is it under 15 words?
   - One clear CTA?
   - Length within platform limits?
   - Any claim, number or quote that isn't verified?
4. Output a scorecard: Measure | Score | Pass/Fix | One-line fix.
5. Verdict: "Reads human" (4 or 5 measures pass) or "Needs work", plus the fixed version if it needs work.

Be honest: this is a quality self-check, not a guarantee against any AI detector. Detectors are unreliable and change often. The real goal is writing that sounds like the user.
