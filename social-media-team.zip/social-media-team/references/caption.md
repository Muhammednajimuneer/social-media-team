# /caption: Instagram or Facebook caption

**Needs:** what the post or reel is about. Optional: CTA keyword, link-in-bio offer.

## Steps
1. First line (under about 125 characters) is a hook that works even without the video.
2. Body: 80 to 200 words, short lines, one idea per line, a real detail.
3. One CTA: comment a keyword, save, share, or link in bio. If a keyword is given, write it exactly as given in capitals.
4. 3 to 5 relevant hashtags at the end: mix one broad, two niche, one branded or local.
5. Apply `banned-words.md`, then show 2 versions (short and long) and the approval gate.
