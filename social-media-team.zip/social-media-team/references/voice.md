# /voice: build the user's voice card

**Needs:** 3 to 5 samples of the user's own writing or speech (posts, captions, emails, video transcripts). Not AI-written drafts.

## Steps
1. Analyse the samples for:
   - sentence length and rhythm,
   - vocabulary level and favourite words or phrases,
   - language mixing (for example English with Malayalam or Arabic words),
   - humour, warmth, directness,
   - emoji and punctuation habits,
   - how they open and close,
   - things they never say.
2. Write a **Voice card** of 200 words or fewer, in this format:

   **Voice card: [Name]**
   - Tone:
   - Sentences:
   - Signature phrases:
   - Language mix:
   - Emoji/punctuation:
   - Openers I use:
   - Closers I use:
   - Never:
   - Sample line in my voice:

3. Tell the user how to keep it: paste it into their Claude project instructions or custom style, or ask Claude to remember it, so every command in this pack uses it.
4. Rewrite one of their samples' topics in the new voice to prove it works.
