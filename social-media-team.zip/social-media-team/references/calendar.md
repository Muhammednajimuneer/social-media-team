# /calendar: 30-day content calendar

**Needs:** start date, platforms, posts per week, pillars. Optional: launches, events, holidays to include (Ramadan, Eid, Onam, Diwali, national days, product launches).

## Output
1. A 30-row table: Date | Day | Platform | Pillar | Format | Topic | Hook.
2. Rotate pillars so no pillar repeats more than twice in a row.
3. Put promotional posts after value posts, never 2 promos back to back.
4. Mark 4 batch-creation days.
5. Note key dates and how to use them.

Check the real calendar for dates and weekdays. Offer to export as a spreadsheet if file tools are available.
