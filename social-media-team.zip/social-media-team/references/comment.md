# /comment: comments on other people's posts

**Needs:** the post text (pasted or screenshot) and who wrote it. Optional: the user's goal (visibility, relationship, lead).

## Steps
1. Read the post and find the one specific point worth responding to.
2. Write 3 options, each 2 to 4 sentences:
   - **Add value:** agree and add a real example, tip or number from the user's experience.
   - **Respectful angle:** a different view, stated politely, with a reason.
   - **Smart question:** a specific question that continues the conversation.
3. No generic praise ("Great post!"), no links, no self-promotion, no pitching in comments.
4. Apply `banned-words.md`.

The user copies and posts the comment themselves. Never suggest automating comments: LinkedIn, Instagram and Facebook all restrict automated activity, and it puts the account at risk.
