# /news: daily AI news carousel

**Needs:** nothing. Optional: niche (marketing, business, education), region, number of stories (default 5).

## Steps
1. If web search is available, find the most important AI stories from the last 24 to 48 hours. Check today's date first. Prefer primary sources (company blogs, official announcements, reputable outlets).
2. Verify each story against at least one solid source. Skip rumours or present them clearly as unconfirmed.
3. If web search is not available, ask the user to paste the stories or links.
4. Build the carousel:
   - Slide 1: "AI news, [date]" plus a hook naming the biggest story.
   - One slide per story: headline (8 words or fewer), what happened (2 sentences), why it matters to the audience (1 line), source and date in small text.
   - Last slide: CTA (follow for daily AI news, or a keyword).
5. Write a caption via /caption rules.
6. Never invent figures, quotes or release dates. Finish with the approval gate.
