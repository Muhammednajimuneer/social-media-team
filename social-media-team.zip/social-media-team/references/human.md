# /human: strip AI-sounding writing

**Needs:** the draft.

## Steps
1. Apply every rule in `banned-words.md`.
2. Vary sentence length. Break long chains into a short punch plus a longer line.
3. Add contractions and first person where natural.
4. Find the one place that needs a concrete detail. If the draft has none, ask the user for one real number, name or moment. Never invent it.
5. Keep the meaning, facts and length roughly the same.
6. Show the clean version in a copy-ready block, then a one-line summary of what changed (for example "removed 3 em dashes, 5 AI words, the generic closer").
7. Offer /check to score it.
