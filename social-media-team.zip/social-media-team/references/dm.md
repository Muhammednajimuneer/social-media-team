# /dm: qualify a lead and draft the reply

**Needs:** the DM conversation so far, and what the user sells or offers.

## Steps
1. Identify the stage: cold (just said hi), curious (asking what it is), warm (asking how it works for them), ready (asking price, dates, how to join), or support (existing customer).
2. Draft a reply of 60 words or fewer that:
   - answers what they actually asked,
   - asks one question to qualify (their need, timing, or role), never more than one,
   - offers one clear next step (a link, a call, a WhatsApp chat, the free resource).
3. Tone: warm, human, zero pressure. No fake scarcity.
4. Add a 2-line **lead note** for the user: who they are, what they want, suggested follow-up and when.
5. The user sends the message themselves.
