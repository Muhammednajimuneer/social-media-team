# Humanizer rules

## 1. Punctuation
- No em dashes (—) or en dashes used as dashes (–). Replace with a full stop, comma, colon or brackets.
- No semicolons in social posts.
- Max one exclamation mark per post.

## 2. Words to remove or replace

| AI word | Use instead |
|---|---|
| delve, dive into, deep dive | look at, dig into |
| crucial, pivotal, vital, paramount | key, important, or cut it |
| leverage, harness, utilize | use |
| robust | solid, strong |
| seamless, seamlessly | smooth, easy |
| moreover, furthermore, additionally | also, and, or cut it |
| unlock, unleash | get, open up |
| elevate, supercharge, turbocharge | improve, speed up |
| empower | help, let |
| game-changer, game-changing, revolutionary, revolutionize | say what it actually changes |
| cutting-edge, state-of-the-art | new, latest |
| landscape, realm, sphere, tapestry | world, field, or cut it |
| navigate (non-literal) | handle, deal with |
| foster | build, grow |
| embark, journey (non-literal) | start, process |
| testament to | shows |
| transformative | big, major |
| streamline | simplify, speed up |
| boost (overused) | raise, grow, improve |
| ultimately, essentially, arguably | cut it |
| comprehensive | full, complete |
| myriad, plethora | many, lots of |
| meticulous, meticulously | careful, carefully |
| in conclusion, to sum up | cut it |

## 3. Patterns to remove
- Throat-clearing openers: "In today's fast-paced world", "In the ever-evolving world of", "Let's dive in", "Here's the thing".
- "It's not just X, it's Y" and "It's not X. It's Y." constructions.
- Reflexive groups of three adjectives ("fast, simple and powerful") when one would do.
- Generic closers: "What do you think?", "Let me know your thoughts!", "The future is here." Replace with a specific question or CTA.
- Emoji at the start of every line, and rocket/sparkle emoji used as decoration.
- Every sentence the same length. Mix short punches with longer lines.

## 4. Add what humans add
- Contractions (it's, you'll, I've).
- One concrete detail: a real number, name, place, tool or moment. Ask the user if you don't have one.
- First person where it fits.
