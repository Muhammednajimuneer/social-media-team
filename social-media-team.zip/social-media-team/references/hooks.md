# Hook library (30 formulas)

Pick formulas that fit the topic and the user's real material. Never fill a formula with invented facts: if a hook needs a number, a result or a story, use the user's real one or a [placeholder].

| # | Formula | Template | Best for |
|---|---|---|---|
| 1 | Story Open | "[Time] ago I [real low point]. Today [real result]." | Founder stories, lessons |
| 2 | Contrarian Take | "Unpopular opinion: [common belief] is wrong." | Opinions, debates |
| 3 | Curiosity Gap | "Nobody talks about the [thing] behind [result]." | Tutorials, insights |
| 4 | The Warning | "Stop [common action] before it costs you [thing]." | Tips, mistakes |
| 5 | Hot Take | "[Bold claim about the industry]. Here's why." | Opinions |
| 6 | Myth Bust | "[Myth]? Not true. Here's what actually happens." | Education |
| 7 | Before/After | "Before: [old way]. After: [new way]." | Tools, transformations |
| 8 | Numbered List | "[N] [things] that [result]." | Tips, resources |
| 9 | Direct Question | "Why do [audience] still [behaviour]?" | Engagement |
| 10 | Costly Mistake | "I made a [real cost] mistake so you don't have to." | Lessons |
| 11 | Real Stat | "[Verified stat]. Here's what it means for you." | News, data |
| 12 | How I | "How I [result] in [time] without [pain]." | Case studies |
| 13 | Steal This | "Steal my [template/prompt/checklist]." | Free resources |
| 14 | Versus | "[A] vs [B]: which one actually [goal]?" | Reviews, comparisons |
| 15 | Prediction | "In 12 months, [prediction]. Get ready now." | Trends, AI news |
| 16 | Confession | "I'll be honest: I used to [thing I'm not proud of]." | Trust, relatability |
| 17 | Behind the Scenes | "Here's what [event/project] really looked like." | Events, process |
| 18 | Unexpected Teacher | "What [unexpected source] taught me about [topic]." | Lessons |
| 19 | Challenge | "Try this for 7 days: [action]." | Habits, tips |
| 20 | 30-Second Win | "This [tool/prompt] does [result] in 30 seconds." | Tool highlights |
| 21 | Callout | "If you're a [role] still [doing X], read this." | Targeted value |
| 22 | Newsjack | "[News] just happened. Here's what it means for [audience]." | AI news |
| 23 | Pattern Reveal | "I looked at [N] [things]. The best ones all had [trait]." | Analysis |
| 24 | Named Framework | "The [name] method: 3 steps to [result]." | Teaching |
| 25 | Before You | "Before you [action], watch this." | Warnings, buying decisions |
| 26 | Replacement | "[Tool] just replaced [task/job]." | Tool news |
| 27 | Insider | "What [experts] rarely tell you about [topic]." | Expertise |
| 28 | Free Version | "This costs $0 and does what [paid thing] does." | Free tools/resources |
| 29 | POV | "POV: you [relatable situation]." | Relatable content, reels |
| 30 | The Fork | "You can [hard way]. Or you can [easy way]." | Promos, tutorials |

## Hook rules

- Under 15 words for text, under 3 seconds spoken for video.
- Specific beats clever. "Cut my proposal time from 3 hours to 20 minutes" beats "a game-changing productivity hack".
- Promise only what the content delivers.
- For video, pair each spoken hook with on-screen text of 6 words or fewer.
