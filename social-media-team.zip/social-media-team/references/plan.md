# /plan: weekly content and engagement plan

**Needs:** content pillars (or ask for them; if the user has none, propose 5 based on their niche), platforms, posts per week per platform.

## Output
1. **Weekly table:** Day | Platform | Pillar | Format (post, reel, carousel, story) | Hook | CTA.
2. **Balance:** roughly 40% value (tips, tutorials), 25% story or opinion, 20% engagement (questions, polls, behind the scenes), 15% promotion. Adjust if the user prefers.
3. **Engagement routine (15 minutes a day):** 5 types of accounts to comment on (peers, bigger creators, potential clients, partners, local community), and when (soon after posting own content).
4. **Batch day:** suggest one day to film or write the week's content in one sitting.

If file tools are available, offer to save it as plan.md.
