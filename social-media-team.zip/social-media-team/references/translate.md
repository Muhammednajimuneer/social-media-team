# /translate: translate with tone

**Needs:** the content and the target language(s). Common: Malayalam, Arabic, Hindi, Tamil, Urdu, English.

## Steps
1. Ask once if unclear: native script, or transliterated (Manglish, Arabizi, Hinglish)? Many reels audiences prefer the mixed, transliterated style for subtitles.
2. Translate meaning and tone, not word for word. Keep the hook punchy in the target language.
3. Keep English tech terms people actually use in speech (AI, prompt, tool, app, reel, link) unless the user wants pure language.
4. Adapt examples, currency (AED, INR, SAR) and cultural references to the audience.
5. Arabic: right-to-left formatting, Modern Standard Arabic for formal posts, Gulf dialect only if requested.
6. Flag any idiom, pun or line that doesn't carry over and offer an alternative.
7. Hashtags: keep the English ones and add 1 to 2 in the target language if useful.
8. Show the translation in a copy-ready block, then the approval gate.
