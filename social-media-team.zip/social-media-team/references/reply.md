# /reply: sort comments and draft replies

**Needs:** the comments on the user's post (pasted or screenshot) and what the post was about.

## Steps
1. Sort every comment into one of these:
   - **Lead:** buying signal ("how much?", "do you do this for companies?", asked for the keyword).
   - **Question:** wants to know something.
   - **Peer:** expert or fellow creator adding to the topic.
   - **Praise:** thanks or compliments.
   - **Critic:** disagreement or complaint.
   - **Noise:** spam, bots, emojis only.
2. Show a table: Commenter | Category | Draft reply. Order: leads first, then questions, peers, critics, praise. Noise gets "skip or hide".
3. Reply rules:
   - Leads: answer briefly in public and invite them to DM. Never post prices or personal details publicly unless the user says so.
   - Critics: calm, specific, no sarcasm. Acknowledge the fair part.
   - Praise: short and personal, ideally with a question.
   - Every reply sounds different. No copy-paste replies.
4. Apply `banned-words.md`. The user posts the replies themselves.
