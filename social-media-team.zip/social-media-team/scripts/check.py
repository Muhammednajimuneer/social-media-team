#!/usr/bin/env python3
"""Social Media Team: draft self-check.

Scores a draft on 5 measures. This is a quality check, not a guarantee
against any AI detector.

Usage: python check.py draft.txt   (or pipe text in: cat draft.txt | python check.py)
"""
import re
import statistics
import sys

AI_WORDS = [
    "delve", "dive into", "deep dive", "crucial", "pivotal", "vital", "paramount",
    "leverage", "harness", "utilize", "robust", "seamless", "seamlessly", "moreover",
    "furthermore", "additionally", "unlock", "unleash", "elevate", "supercharge",
    "turbocharge", "empower", "game-changer", "game-changing", "revolutionary",
    "revolutionize", "cutting-edge", "state-of-the-art", "landscape", "realm",
    "tapestry", "foster", "embark", "testament", "transformative", "streamline",
    "ultimately", "essentially", "arguably", "comprehensive", "myriad", "plethora",
    "meticulous", "meticulously", "in conclusion", "to sum up",
]
PATTERNS = [
    r"in today'?s (fast-paced|digital|ever-changing)",
    r"ever-evolving",
    r"let'?s dive",
    r"here'?s the thing",
    r"it'?s not just",
    r"\bnot just\b.*\bbut\b",
    r"it'?s not \w+[^.]*[.,] it'?s",
    r"what do you think\?",
    r"let me know your thoughts",
    r"the future is here",
]


def sentences(text):
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [p.strip() for p in parts if len(p.split()) >= 2]


def main():
    text = open(sys.argv[1], encoding="utf-8").read() if len(sys.argv) > 1 else sys.stdin.read()
    words = re.findall(r"[\w'’-]+", text)
    n = max(len(words), 1)
    lower = text.lower()
    results = []

    # 1. Burstiness: variation in sentence length
    lens = [len(s.split()) for s in sentences(text)]
    if len(lens) >= 3:
        cv = statistics.pstdev(lens) / statistics.mean(lens)
        results.append(("Burstiness", f"{cv:.2f}", cv >= 0.45, "Mix very short sentences with longer ones."))
    else:
        results.append(("Burstiness", "n/a", True, "Too short to measure."))

    # 2. Specificity: numbers and proper nouns per 100 words
    nums = len(re.findall(r"\b\d[\d,.%]*\b", text))
    proper = len(re.findall(r"(?<![.!?]\s)(?<!^)\b[A-Z][a-z]{2,}\b", text, flags=re.M))
    spec = (nums + proper) / n * 100
    results.append(("Specificity", f"{spec:.1f}/100w", spec >= 2, "Add a real number, name, tool or place."))

    # 3. Slop density: AI words per 100 words
    found = [w for w in AI_WORDS if re.search(r"\b" + re.escape(w) + r"\b", lower)]
    slop = sum(len(re.findall(r"\b" + re.escape(w) + r"\b", lower)) for w in AI_WORDS) / n * 100
    results.append(("Slop density", f"{slop:.1f}/100w", slop == 0,
                    "Replace: " + ", ".join(found) if found else "Clean."))

    # 4. Fingerprint: AI patterns and em/en dashes
    dashes = text.count("\u2014") + len(re.findall(r"\s\u2013\s", text))
    pats = [p for p in PATTERNS if re.search(p, lower)]
    fp_hits = dashes + len(pats)
    results.append(("Fingerprint", f"{dashes} dashes, {len(pats)} patterns", fp_hits == 0,
                    "Remove em dashes and stock AI phrasing."))

    # 5. Voice: first person and contractions
    first = len(re.findall(r"\b(i|i'm|i've|i'll|my|me|we|our)\b", lower))
    contr = len(re.findall(r"\b\w+['’](s|re|ve|ll|d|m|t)\b", lower))
    voice_ok = first > 0 and contr > 0
    results.append(("Voice", f"{first} first-person, {contr} contractions", voice_ok,
                    "Write as yourself: use I/we and contractions."))

    print(f"{'Measure':<14}{'Score':<36}{'Result':<8}Fix")
    for name, score, ok, fix in results:
        print(f"{name:<14}{score:<36}{'PASS' if ok else 'FIX':<8}{'' if ok else fix}")
    passed = sum(1 for r in results if r[2])
    print()
    print(f"Verdict: {'Reads human' if passed >= 4 else 'Needs work'} ({passed}/5 passed)")
    print("Note: a quality self-check, not a guarantee against any AI detector.")


if __name__ == "__main__":
    main()
